Bước 1: Chép file QLThuVien.apk vào điện thoại.
Bước 2: Mở file chọn Install
Bước 3: Nếu có lựa chọn, chọn Install anyway
